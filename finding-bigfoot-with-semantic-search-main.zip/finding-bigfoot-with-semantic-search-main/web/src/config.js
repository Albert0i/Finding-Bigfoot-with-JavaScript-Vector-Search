export const API_BASE_URL = import.meta.env.VITE_API_BASE_URL ?? '/api'
export const RESULT_COUNT = Number(import.meta.env.VITE_RESULT_COUNT ?? 10)
