import HomeView from './views/home.js'
import SearchView from './views/search.js'
import SightingView from './views/sighting.js'

import router from './router.js'
